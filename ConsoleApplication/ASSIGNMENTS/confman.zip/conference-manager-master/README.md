CTM
===

Conference Track Management

A quick application quiz. It does a simple sort for conference scheduling.
